<?php
$_['modal_title'] = 'Attention';
$_['modal_agree'] = 'Yes';
$_['modal_disagree'] = 'No';